# Atmasamman Group — Vercel Deployment Guide

## Architecture
- **Frontend**: React (Create React App) → Deploy as Vercel Static Site
- **Backend**: Node.js/Express → Deploy as Vercel Serverless Functions
- Both deployed as **separate Vercel projects**

---

## STEP 1 — Deploy the Backend

### 1.1 Push backend to GitHub
```bash
# In your terminal:
cd backend
git init
git add .
git commit -m "Initial backend"
git remote add origin https://github.com/YOUR_USERNAME/atmasamman-backend.git
git push -u origin main
```

### 1.2 Import into Vercel
1. Go to https://vercel.com/new
2. Click **"Import Git Repository"** → select `atmasamman-backend`
3. **Root Directory**: leave empty (it's the whole repo)
4. **Framework Preset**: Other
5. **Build Command**: leave empty
6. **Output Directory**: leave empty

### 1.3 Add Backend Environment Variables in Vercel
In Vercel dashboard → Settings → Environment Variables, add:

| Key | Value |
|-----|-------|
| `NODE_ENV` | `production` |
| `MONGODB_URI` | `mongodb+srv://user:pass@cluster.mongodb.net/atmasamman` |
| `FIREBASE_PROJECT_ID` | your Firebase project ID |
| `FIREBASE_CLIENT_EMAIL` | service account email |
| `FIREBASE_PRIVATE_KEY` | full private key with `\n` newlines |
| `FRONTEND_URL` | (set AFTER frontend is deployed — e.g. `https://your-frontend.vercel.app`) |

### 1.4 Deploy — note your backend URL
After deploy, copy your backend URL: `https://atmasamman-backend.vercel.app`

---

## STEP 2 — Deploy the Frontend

### 2.1 Push frontend to GitHub
```bash
cd frontend
git init
git add .
git commit -m "Initial frontend"
git remote add origin https://github.com/YOUR_USERNAME/atmasamman-frontend.git
git push -u origin main
```

### 2.2 Import into Vercel
1. Go to https://vercel.com/new
2. Click **"Import Git Repository"** → select `atmasamman-frontend`
3. **Root Directory**: leave empty
4. **Framework Preset**: Create React App
5. **Build Command**: `npm run build` (already set)
6. **Output Directory**: `build`

### 2.3 Add Frontend Environment Variables in Vercel
| Key | Value |
|-----|-------|
| `REACT_APP_FIREBASE_API_KEY` | from Firebase Console |
| `REACT_APP_FIREBASE_AUTH_DOMAIN` | `your-project.firebaseapp.com` |
| `REACT_APP_FIREBASE_PROJECT_ID` | your project ID |
| `REACT_APP_FIREBASE_STORAGE_BUCKET` | `your-project.appspot.com` |
| `REACT_APP_FIREBASE_MESSAGING_SENDER_ID` | sender ID |
| `REACT_APP_FIREBASE_APP_ID` | app ID |
| `REACT_APP_API_URL` | `https://atmasamman-backend.vercel.app` |

### 2.4 Deploy
Click Deploy — your frontend will be live in ~2 minutes.

---

## STEP 3 — Post-Deployment

### Update backend CORS
Go to your **backend** Vercel project → Settings → Environment Variables  
Update `FRONTEND_URL` = `https://your-frontend.vercel.app`  
Then **Redeploy** the backend.

### Firebase Auth — Authorize domain
1. Firebase Console → Authentication → Settings → Authorized domains
2. Add your frontend Vercel domain: `your-frontend.vercel.app`

### Firebase Storage Rules
Make sure Firebase Storage rules allow authenticated uploads for career applications.

---

## Environment Variables Quick Reference

### Frontend (.env.example → set in Vercel)
```
REACT_APP_FIREBASE_API_KEY=
REACT_APP_FIREBASE_AUTH_DOMAIN=
REACT_APP_FIREBASE_PROJECT_ID=
REACT_APP_FIREBASE_STORAGE_BUCKET=
REACT_APP_FIREBASE_MESSAGING_SENDER_ID=
REACT_APP_FIREBASE_APP_ID=
REACT_APP_API_URL=
```

### Backend (.env.example → set in Vercel)
```
NODE_ENV=production
MONGODB_URI=
FIREBASE_PROJECT_ID=
FIREBASE_CLIENT_EMAIL=
FIREBASE_PRIVATE_KEY=
FRONTEND_URL=
```
